//
//  ClickerApp.swift
//  Clicker
//
//  Created by Danielle Eliza Salang Yap on 6/8/23.
//

import SwiftUI

@main
struct ClickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
